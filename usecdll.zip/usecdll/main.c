#include <stdio.h>

typedef struct Teacher{
    int tid;
    char *t_name;
}Teacher;

typedef struct Student{
    int id;
    char *name;
    Teacher *teacher;
}Student;
int main() {

    Student *student;

    hello(student);
    return 0;
}

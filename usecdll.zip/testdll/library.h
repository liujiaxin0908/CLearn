#ifndef CTEST_LIBRARY_H
#define CTEST_LIBRARY_H
typedef struct Teacher{
    int tid;
    char *t_name;
}Teacher;

typedef struct Student{
    int id;
    char *name;
    Teacher *teacher;
}Student;



void hello(Student *student);


#endif //CTEST_LIBRARY_H

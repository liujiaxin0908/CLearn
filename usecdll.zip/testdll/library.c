#include "library.h"

#include <stdio.h>
#include "malloc.h"

void hello(Student *student) {
    student = (Student *) malloc(sizeof(student));
    Teacher *teacher = NULL;
    teacher = (Teacher *) malloc(sizeof(Teacher));
    student->id = 1001;
    student->name = "hangman";
    teacher->t_name = "lisisi";
    teacher->tid = 10123;
    student->teacher = teacher;
    &student;
    printf("id=%d   name=%s   tid=%d  t_name=%s\n", student->id, student->name, student->teacher->tid,
           student->teacher->t_name);
}